package com.example.registrationform

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
